load('honk')
setExtensionUnloadMode('honk', 'manual')
